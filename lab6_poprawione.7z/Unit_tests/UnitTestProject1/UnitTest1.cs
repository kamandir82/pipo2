﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Unit_tests;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Fibonacci_8()
        {
            Fib FF1 = new Fib();
            FF1.n = 8;
            Assert.AreEqual(FF1.zwroc(), 21);
        }
        [TestMethod]
        public void Fibonacci_0()
        {
            Fib FF1 = new Fib();
            FF1.n = 0;
            Assert.AreEqual(FF1.zwroc(), 0);
        }
    }
}
