﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Unit_tests
{
    public class Fib
    {
        public int n;
        public int zwroc()
        {
            if (n == 0) return 0;
            if ((n == 1)||(n==2)) return 1;
            if (n == 3) return 2;
            int i = 4;
            int x1 = 1, x2 = 2;
            while(i<=n)
            {
                int temp = x2;
                x2 = x2 + x1;
                x1 = temp;
                i++;
            }
            return x2;
        }
    }
}
