﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Unit_tests
{
    class Program
    {
        static void Main(string[] args)
        {
            Fib F1 = new Fib();
            F1.n = 12;
            Console.WriteLine(F1.zwroc());
            Console.ReadKey();
        }
    }
}
